"use strict";
var RangeObservable_1 = require('./RangeObservable');
exports.range = RangeObservable_1.RangeObservable.create;
//# sourceMappingURL=range.js.map