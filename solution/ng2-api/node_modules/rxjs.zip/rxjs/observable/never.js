"use strict";
var NeverObservable_1 = require('./NeverObservable');
exports.never = NeverObservable_1.NeverObservable.create;
//# sourceMappingURL=never.js.map